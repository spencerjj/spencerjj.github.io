module.exports = {
  APP_ID: 1,
  APP_VER: '1.0.0',
  CHANNEL_ID: 'MiniProgram',
  APPEND_WORD: 'dianshang!',
  PARTNER_TYPE: 'wechat_mp',
  // HOST_URI: 'http://192.168.2.81:8980/',//范
  // HOST_URI: 'http://192.168.2.50:8980/', //刘
  HOST_URI:'https://bhwhy.cbxsj.com/',
  store:'购物中心',
  storeId:'601'
};